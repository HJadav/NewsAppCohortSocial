import axios from 'axios';

const API_KEY = '62954f02631a4335a3acaf3a8b34e9ed';
const BASE_URL = 'https://newsapi.org/v2';

export const fetchArticles = async (category = 'general', page = 1) => {
  const response = await axios.get(`${BASE_URL}/top-headlines`, {
    params: {
      category,
      apiKey: API_KEY,
      page,
      pageSize: 10,
    },
  });
  console.log('res',JSON.stringify(response,null,2));
  
  return response.data.articles;
};
