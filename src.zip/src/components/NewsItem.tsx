import React from 'react';
import { View, Text, Image, TouchableOpacity } from 'react-native';

const NewsItem = ({ article }) => {
  return (
    <TouchableOpacity>
      <View>
        <Image source={{ uri: article.urlToImage }} style={{ width: '100%', height: 200 }} />
        <Text>{article.title}</Text>
        <Text>{article.description}</Text>
      </View>
    </TouchableOpacity>
  );
};

export default NewsItem;
