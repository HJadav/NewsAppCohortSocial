import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from '@react-navigation/native';
import NewsFeed from '../screens/NewsFeed';
import Bookmarks from '../screens/Bookmarks';
// import Bookmarks from '../screens/Bookmarks';

const Tab = createBottomTabNavigator();

const AppNavigator = () => {
  return (
    <NavigationContainer>
      <Tab.Navigator>
        <Tab.Screen name="News" component={NewsFeed} />
        <Tab.Screen name="Bookmarks" component={Bookmarks} />
      </Tab.Navigator>
    </NavigationContainer>
  );
};

export default AppNavigator;
