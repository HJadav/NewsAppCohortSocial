import { createSlice } from '@reduxjs/toolkit';
import AsyncStorage from '@react-native-async-storage/async-storage';

const bookmarkSlice = createSlice({
  name: 'bookmarks',
  initialState: {
    articles: [],
  },
  reducers: {
    addBookmark: (state, action) => {
      state.articles.push(action.payload);
      AsyncStorage.setItem('bookmarks', JSON.stringify(state.articles));
    },
    removeBookmark: (state, action) => {
      state.articles = state.articles.filter(
        (article) => article.url !== action.payload.url
      );
      AsyncStorage.setItem('bookmarks', JSON.stringify(state.articles));
    },
    loadBookmarks: (state, action) => {
      state.articles = action.payload;
    },
  },
});

export const { addBookmark, removeBookmark, loadBookmarks } = bookmarkSlice.actions;
export default bookmarkSlice.reducer;
