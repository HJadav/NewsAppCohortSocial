import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

export const fetchNews = createAsyncThunk(
  'news/fetchNews',
  async (category: string = 'general', { getState }) => {
    const { page } = getState().news;
    const response = await axios.get(`https://newsapi.org/v2/top-headlines`, {
      params: {
        category,
        apiKey: '62954f02631a4335a3acaf3a8b34e9ed',
        page,
        pageSize: 10,
      },
    });
    return response.data.articles;
  }
);

const newsSlice = createSlice({
  name: 'news',
  initialState: {
    articles: [],
    loading: false,
    error: null,
    page: 1,
  },
  reducers: {
    resetNews: (state) => {
      state.articles = [];
      state.page = 1;
    },
    incrementPage: (state) => {
      state.page += 1;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchNews.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchNews.fulfilled, (state, action) => {
        state.articles = [...state.articles, ...action.payload];
        state.loading = false;
      })
      .addCase(fetchNews.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message;
      });
  },
});

export const { resetNews, incrementPage } = newsSlice.actions;
export default newsSlice.reducer;
