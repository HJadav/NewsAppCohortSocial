import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

interface Article {
  id: string;
  title: string;
  description: string;
  url: string;
  urlToImage: string;
}

interface ArticlesState {
  articles: Article[];
  loading: boolean;
  error: string | null;
}

const initialState: ArticlesState = {
  articles: [],
  loading: false,
  error: null,
};

export const fetchArticles = createAsyncThunk(
  'articles/fetchArticles',
  async (category: string) => {
    const response = await axios.get(`https://newsapi.org/v2/top-headlines?category=${category}&apiKey=YOUR_API_KEY`);
    return response.data.articles;
  }
);

const articlesSlice = createSlice({
  name: 'articles',
  initialState,
  reducers: {
    clearArticles(state) {
      state.articles = [];
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchArticles.pending, (state) => {
        state.loading = true;
      })
      .addCase(fetchArticles.fulfilled, (state, action) => {
        state.loading = false;
        state.articles = action.payload;
        state.error = null;
      })
      .addCase(fetchArticles.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || 'Failed to fetch articles';
      });
  },
});

export const { clearArticles } = articlesSlice.actions;
export default articlesSlice.reducer;
