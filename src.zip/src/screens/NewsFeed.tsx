import React, { useEffect } from 'react';
import { View, Text, FlatList, ActivityIndicator, Button } from 'react-native';
import { useDispatch, useSelector } from 'react-redux';
import { fetchNews, incrementPage, resetNews } from '../store/newsSlice';
import { RootState } from '../store';
import NewsItem from '../components/NewsItem';

const categories = ['general', 'technology', 'business', 'sports', 'entertainment'];

const NewsFeed = () => {
  const dispatch = useDispatch();
  const { articles, loading, page } = useSelector((state: RootState) => state.news);


  
  useEffect(() => {
    dispatch(fetchNews());
  }, [dispatch]);

  const loadMore = () => {
    dispatch(incrementPage());
    dispatch(fetchNews());
  };

  const renderItem = ({ item }) => <NewsItem article={item} />;

  return (
    <View>
      <FlatList
        data={articles}
        renderItem={renderItem}
        keyExtractor={(item) => item.url}
        onEndReached={loadMore}
        ListFooterComponent={loading && <ActivityIndicator size="large" />}
      />
    </View>
  );
};

export default NewsFeed;
