import React, { useEffect } from 'react';
import { View, Text, FlatList } from 'react-native';
import { useSelector, useDispatch } from 'react-redux';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { loadBookmarks } from '../store/bookmarkSlice';
import { RootState } from '../store';
import NewsItem from '../components/NewsItem';

const Bookmarks = () => {
  const dispatch = useDispatch();
  const { articles } = useSelector((state: RootState) => state.bookmarks);

  useEffect(() => {
    const fetchBookmarks = async () => {
      const savedBookmarks = await AsyncStorage.getItem('bookmarks');
      if (savedBookmarks) {
        dispatch(loadBookmarks(JSON.parse(savedBookmarks)));
      }
    };
    fetchBookmarks();
  }, [dispatch]);

  return (
    <View>
      <FlatList
        data={articles}
        renderItem={({ item }) => <NewsItem article={item} />}
        keyExtractor={(item) => item.url}
      />
    </View>
  );
};

export default Bookmarks;
